/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Scanner;


import java.util.Scanner;

/**
 *
 * @author NURDIN
 */
public class Menghitungluasbalok {

    public static void main(String[] args) {
        Scanner scan = new Scanner (System.in);
        int luas, panjang, lebar, tinggi;
        
        System.out.print("Masukan nilai panjang =");
        panjang = Integer.parseInt(scan.nextLine());
        
        System.out.print("Masukan nilai lebar =");
        lebar = Integer.parseInt(scan.nextLine());
        
        System.out.print("Masukan nilai tinggi =");
        tinggi = Integer.parseInt(scan.nextLine());
        
        luas = 2*panjang*lebar+2*lebar*tinggi+2*panjang*tinggi;
        System.out.println("hasil luas balok ="+luas);
        
        
    
    }
    
}
